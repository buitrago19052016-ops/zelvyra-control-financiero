import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Plus, Minus, X, Trash2, TrendingUp, ArrowUpRight, ArrowDownRight,
  Settings2, Calculator, PiggyBank, AlertTriangle, Sparkles, Target
} from 'lucide-react';

// v2 intentionally starts with a clean profile so ZELVYRA is reusable by anyone.
const STORAGE_KEY = 'zelvyra-control-financiero-v2';
const META_ID = 'principal';

const fmt = (n) => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(Math.round(n || 0));
const todayISO = () => new Date().toISOString().slice(0, 10);
const daysBetween = (a, b) => Math.max(0, Math.round((new Date(b) - new Date(a)) / 86400000));
const monthKey = (date) => String(date).slice(0, 7);
const parseMoney = (value) => parseInt(String(value).replace(/\D/g, ''), 10) || 0;

function defaultData() {
  return {
    startDate: todayISO(),
    ingresoMensual: 0,
    gastosMensual: 0,
    metaNombre: '',
    metaObjetivo: 0,
    metaPlazoMeses: 0,
    transacciones: [],
  };
}

function useFinanceData() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      let loaded = null;
      try {
        if (window.storage?.get) {
          const res = await window.storage.get(STORAGE_KEY, false);
          if (res?.value) loaded = JSON.parse(res.value);
        }
      } catch (_) {}
      if (!loaded) {
        try {
          const raw = window.localStorage.getItem(STORAGE_KEY);
          if (raw) loaded = JSON.parse(raw);
        } catch (_) {}
      }
      setData(loaded ? { ...defaultData(), ...loaded } : defaultData());
      setLoading(false);
    })();
  }, []);

  const persist = useCallback(async (next) => {
    setData(next);
    setSaving(true);
    try { if (window.storage?.set) await window.storage.set(STORAGE_KEY, JSON.stringify(next), false); } catch (_) {}
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); } catch (_) {}
    setSaving(false);
  }, []);

  return { data, loading, saving, persist };
}

function ProgressRing({ pct, color = '#D7AF58', size = 132, stroke = 11 }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const clamped = Math.min(100, Math.max(0, pct));
  const offset = c - (clamped / 100) * c;
  return <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
    <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#2B241A" strokeWidth={stroke} />
    <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeDasharray={c} strokeDashoffset={offset} strokeLinecap="round" style={{ transition: 'stroke-dashoffset .6s ease' }} />
  </svg>;
}

function Modal({ title, children, onCancel }) {
  return <div className="modal-backdrop" onClick={onCancel}>
    <div className="modal" onClick={(e) => e.stopPropagation()}>
      <div className="modal-head"><span>{title}</span><button className="icon-btn" onClick={onCancel}><X size={18} /></button></div>
      {children}
    </div>
  </div>;
}

function GoalForm({ data, onCancel, onSave, firstTime = false }) {
  const [nombre, setNombre] = useState(data.metaNombre || '');
  const [objetivo, setObjetivo] = useState(data.metaObjetivo ? String(data.metaObjetivo) : '');
  const [meses, setMeses] = useState(data.metaPlazoMeses ? String(data.metaPlazoMeses) : '');
  const [ingreso, setIngreso] = useState(data.ingresoMensual ? String(data.ingresoMensual) : '');
  const [gastos, setGastos] = useState(data.gastosMensual ? String(data.gastosMensual) : '');

  const submit = () => {
    const obj = parseMoney(objetivo);
    const plazo = Math.max(0, parseInt(meses, 10) || 0);
    if (!obj || !plazo) return;
    onSave({
      ...data,
      startDate: data.metaObjetivo === obj && data.metaPlazoMeses === plazo ? data.startDate : todayISO(),
      metaNombre: nombre.trim() || 'Mi meta de ahorro',
      metaObjetivo: obj,
      metaPlazoMeses: plazo,
      ingresoMensual: parseMoney(ingreso),
      gastosMensual: parseMoney(gastos),
    });
  };

  return <Modal title={firstTime ? 'Configura tu meta de ahorro' : 'Mi meta y presupuesto'} onCancel={onCancel}>
    {firstTime && <p className="setup-text">ZELVYRA empieza desde cero. Elige cuánto quieres ahorrar y en cuántos meses.</p>}
    <label className="field-label">Nombre de la meta</label>
    <input className="field-input" placeholder="Ej: Universidad, casa, viaje..." value={nombre} onChange={(e) => setNombre(e.target.value)} autoFocus={firstTime} />
    <label className="field-label">¿Cuánto quieres ahorrar?</label>
    <input className="field-input" inputMode="numeric" placeholder="$ 0" value={objetivo ? Number(objetivo).toLocaleString('es-CO') : ''} onChange={(e) => setObjetivo(e.target.value.replace(/\D/g, ''))} />
    <label className="field-label">¿En cuántos meses?</label>
    <input className="field-input" inputMode="numeric" type="number" min="1" placeholder="Ej: 12" value={meses} onChange={(e) => setMeses(e.target.value.replace(/\D/g, ''))} />
    <label className="field-label">Ingreso mensual estimado (opcional)</label>
    <input className="field-input" inputMode="numeric" placeholder="$ 0" value={ingreso ? Number(ingreso).toLocaleString('es-CO') : ''} onChange={(e) => setIngreso(e.target.value.replace(/\D/g, ''))} />
    <label className="field-label">Gastos mensuales estimados (opcional)</label>
    <input className="field-input" inputMode="numeric" placeholder="$ 0" value={gastos ? Number(gastos).toLocaleString('es-CO') : ''} onChange={(e) => setGastos(e.target.value.replace(/\D/g, ''))} />
    <button className="submit-btn submit-in" onClick={submit}>Guardar mi meta</button>
  </Modal>;
}

function TransactionForm({ tipo, onCancel, onSave }) {
  const [monto, setMonto] = useState('');
  const [nota, setNota] = useState('');
  const [fecha, setFecha] = useState(todayISO());
  const isIngreso = tipo === 'ingreso';
  const isAhorro = tipo === 'ahorro';
  const submit = () => {
    const n = parseMoney(monto);
    if (!n) return;
    onSave({ id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, tipo, monto: n, metaId: isIngreso || isAhorro ? META_ID : null, nota: nota.trim(), fecha });
  };
  return <Modal title={isIngreso ? 'Registrar ingreso' : isAhorro ? 'Registrar ahorro' : 'Registrar gasto'} onCancel={onCancel}>
    <label className="field-label">Monto</label>
    <input className="field-input" inputMode="numeric" placeholder="$ 0" value={monto ? Number(monto).toLocaleString('es-CO') : ''} onChange={(e) => setMonto(e.target.value.replace(/\D/g, ''))} autoFocus />
    <label className="field-label">Fecha</label>
    <input className="field-input" type="date" value={fecha} onChange={(e) => setFecha(e.target.value)} />
    <label className="field-label">Nota (opcional)</label>
    <input className="field-input" placeholder="Ej: sueldo, mercado..." value={nota} onChange={(e) => setNota(e.target.value)} />
    <button className={`submit-btn ${isIngreso || isAhorro ? 'submit-in' : 'submit-out'}`} onClick={submit}>Guardar</button>
  </Modal>;
}

function CalculatorModal({ onCancel }) {
  const [a, setA] = useState(''); const [b, setB] = useState(''); const [op, setOp] = useState('+');
  const x = parseMoney(a), y = parseMoney(b); let result = 0;
  if (op === '+') result = x + y; if (op === '-') result = x - y; if (op === '×') result = x * y; if (op === '÷') result = y ? x / y : 0;
  return <Modal title="Calculadora rápida" onCancel={onCancel}>
    <input className="field-input calc-input" inputMode="numeric" placeholder="$ 0" value={a ? Number(a).toLocaleString('es-CO') : ''} onChange={(e) => setA(e.target.value.replace(/\D/g, ''))} />
    <div className="calc-ops">{['+', '-', '×', '÷'].map((v) => <button key={v} className={op === v ? 'calc-op active' : 'calc-op'} onClick={() => setOp(v)}>{v}</button>)}</div>
    <input className="field-input calc-input" inputMode="numeric" placeholder="$ 0" value={b ? Number(b).toLocaleString('es-CO') : ''} onChange={(e) => setB(e.target.value.replace(/\D/g, ''))} />
    <div className="calc-result">{fmt(result)}</div>
  </Modal>;
}

export default function App() {
  const { data, loading, saving, persist } = useFinanceData();
  const [formTipo, setFormTipo] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showCalc, setShowCalc] = useState(false);
  const [showWelcome, setShowWelcome] = useState(false);
  const [activeView, setActiveView] = useState('resumen');

  useEffect(() => { if (data && !data.metaObjetivo) setShowWelcome(true); }, [data]);

  const saveGoal = (next) => { persist(next); setShowSettings(false); setShowWelcome(false); };
  const addTransaccion = (t) => { persist({ ...data, transacciones: [t, ...data.transacciones] }); setFormTipo(null); };
  const deleteTransaccion = (id) => persist({ ...data, transacciones: data.transacciones.filter((t) => t.id !== id) });

  const calc = useMemo(() => {
    if (!data) return null;
    const ingresos = data.transacciones.filter(t => t.tipo === 'ingreso').reduce((s,t) => s+t.monto, 0);
    const gastos = data.transacciones.filter(t => t.tipo === 'gasto').reduce((s,t) => s+t.monto, 0);
    const ahorros = data.transacciones.filter(t => t.tipo === 'ahorro').reduce((s,t) => s+t.monto, 0);
    const disponible = ingresos - gastos - ahorros;
    const objetivo = Number(data.metaObjetivo) || 0;
    const plazo = Number(data.metaPlazoMeses) || 0;
    const aportado = data.transacciones.filter(t => (t.tipo === 'ahorro' || t.tipo === 'ingreso') && t.metaId === META_ID).reduce((s,t) => s+t.monto, 0);
    const restante = Math.max(0, objetivo - aportado);
    const mensual = plazo ? objetivo / plazo : 0;
    const diario = plazo ? objetivo / (plazo * 30) : 0;
    const elapsed = daysBetween(data.startDate, todayISO());
    const totalDays = Math.max(1, plazo * 30);
    const diasRestantesMeta = Math.max(1, totalDays - elapsed);
    const diarioAlcanzar = objetivo ? restante / diasRestantesMeta : 0;
    const pct = objetivo ? Math.min(100, aportado / objetivo * 100) : 0;
    const capacidad = Math.max(0, (data.ingresoMensual || 0) - (data.gastosMensual || 0));
    const ahora = new Date();
    const finMes = new Date(ahora.getFullYear(), ahora.getMonth()+1, 0);
    const diasRestantesMes = Math.max(1, daysBetween(todayISO(), finMes.toISOString().slice(0,10)) + 1);
    const inicioMes = `${ahora.getFullYear()}-${String(ahora.getMonth()+1).padStart(2,'0')}-01`;
    const ahorradoEsteMes = data.transacciones.filter(t => t.tipo === 'ahorro' && t.fecha >= inicioMes).reduce((s,t) => s+t.monto, 0);
    const presupuestoDiario = Math.max(0, ((data.ingresoMensual || 0) - (data.gastosMensual || 0)) / diasRestantesMes);
    const gastoRatio = data.ingresoMensual ? gastos / Math.max(1, data.ingresoMensual) : 0;
    let estado = 'verde';
    if (objetivo && (ahorradoEsteMes < mensual * .7 || gastoRatio > .8)) estado = 'rojo';
    else if (objetivo && ahorradoEsteMes < mensual) estado = 'amarillo';
    const months = [];
    for (let i=5; i>=0; i--) {
      const d = new Date(ahora.getFullYear(), ahora.getMonth()-i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
      const ahorro = data.transacciones.filter(t => t.tipo==='ahorro' && monthKey(t.fecha)===key).reduce((s,t)=>s+t.monto,0);
      const gasto = data.transacciones.filter(t => t.tipo==='gasto' && monthKey(t.fecha)===key).reduce((s,t)=>s+t.monto,0);
      months.push({ key, label: d.toLocaleDateString('es-CO',{month:'short'}).replace('.',''), ahorro, gasto });
    }
    return { ingresos, gastos, ahorros, disponible, objetivo, plazo, aportado, restante, mensual, diario, diarioAlcanzar, pct, capacidad, estado, diasRestantesMes, presupuestoDiario, ahorradoEsteMes, months };
  }, [data]);

  if (loading || !data || !calc) return <div className="app-shell centered"><style>{CSS}</style><div className="loader">Cargando ZELVYRA…</div></div>;
  const historial = [...data.transacciones].sort((a,b) => b.fecha.localeCompare(a.fecha)).slice(0, 30);
  const maxChart = Math.max(calc.mensual, ...calc.months.map(m=>m.ahorro), 1);
  const goalName = data.metaNombre || 'Mi meta de ahorro';
  const hasGoal = calc.objetivo > 0 && calc.plazo > 0;

  return <div className="app-shell">
    <style>{CSS}</style><div className="texture" /><div className="app-frame">
      <header className="brand"><div className="bat">♠</div><div><div className="brand-name">ZELVYRA</div><div className="brand-sub">CONTROL FINANCIERO</div></div>
        <div className="brand-actions"><button className="icon-btn" onClick={()=>setShowCalc(true)} title="Calculadora"><Calculator size={18}/></button><button className="icon-btn" onClick={()=>setShowSettings(true)} title="Configuración"><Settings2 size={18}/></button></div>
      </header>
      <div className="motto">“Cada peso tiene un propósito.”</div>
      <nav className="tabs"><button className={activeView==='resumen'?'tab active':'tab'} onClick={()=>setActiveView('resumen')}>Resumen</button><button className={activeView==='seis'?'tab active':'tab'} onClick={()=>setActiveView('seis')}>6 meses</button><button className={activeView==='movimientos'?'tab active':'tab'} onClick={()=>setActiveView('movimientos')}>Movimientos</button></nav>

      {activeView==='resumen' && <>
        <section className="available-card"><div className="eyebrow">DINERO DISPONIBLE</div><div className="available-amount">{fmt(calc.disponible)}</div><div className="available-stats"><span><ArrowUpRight size={14}/>{fmt(calc.ingresos)}</span><span><ArrowDownRight size={14}/>{fmt(calc.gastos)}</span></div></section>
        {!hasGoal ? <section className="alert-card amarillo"><div className="alert-icon"><Target size={19}/></div><div><strong>CONFIGURA TU PRIMERA META</strong><p>Todo está en cero. Elige cuánto quieres ahorrar y en cuántos meses.</p><button className="goal-link" onClick={()=>setShowSettings(true)}>Crear mi meta</button></div></section> : <section className={`alert-card ${calc.estado}`}><div className="alert-icon">{calc.estado==='rojo'?<AlertTriangle size={19}/>:<Sparkles size={19}/>}</div><div><strong>{calc.estado==='rojo'?'ATENCIÓN: revisa tus gastos':calc.estado==='amarillo'?'Vas justo con el ahorro':'Vas por buen camino'}</strong><p>Tu ritmo se compara automáticamente con tu meta de {fmt(calc.objetivo)}.</p></div></section>}
        <section className="university-card"><div className="ring-wrap"><ProgressRing pct={calc.pct}/><div className="ring-center"><b>{calc.pct.toFixed(0)}%</b><span>meta</span></div></div><div className="university-info"><div className="card-kicker">{goalName.toUpperCase()}</div><h2>{fmt(calc.objetivo)}</h2><div className="mini-row"><span>Ahorrado</span><b>{fmt(calc.aportado)}</b></div><div className="mini-row"><span>Faltante</span><b>{fmt(calc.restante)}</b></div></div></section>
        <section className="daily-card"><div className="daily-icon"><PiggyBank size={20}/></div><div><div className="card-kicker">RITMO PARA LLEGAR A TU META</div><div className="daily-number">{fmt(calc.diarioAlcanzar)} <small>/ día</small></div><p>{hasGoal ? `Meta en ${calc.plazo} meses. Necesario aprox. ${fmt(calc.mensual)} al mes.` : 'Configura una meta para calcular tu ritmo de ahorro.'}</p></div></section>
        <section className="budget-card"><div className="budget-head"><TrendingUp size={16}/><span>LÍMITE DE GASTO ESTIMADO</span></div><div className="budget-amount">{fmt(calc.presupuestoDiario)}</div><div className="budget-sub">Se calcula con tu ingreso y gastos mensuales configurados. Si están en cero, aquí también verás $0.</div></section>
        <section><div className="section-title">Tu meta</div><div className="meta-card"><div className="meta-icon" style={{color:'#D7AF58',borderColor:'#D7AF5855'}}><Target size={17}/></div><div className="meta-nombre">{goalName}</div><div className="meta-monto">{fmt(calc.aportado)}</div><div className="meta-objetivo">de {fmt(calc.objetivo)}</div><div className="meta-bar-track"><div className="meta-bar-fill" style={{width:`${calc.pct}%`,background:'#D7AF58'}}/></div></div></section>
        <section><div className="section-title">Últimos movimientos</div>{historial.length===0?<div className="empty-state">Aún no hay movimientos.</div>:<div className="hist-list">{historial.slice(0,6).map(t=><TransactionRow key={t.id} t={t} onDelete={deleteTransaccion}/>)}</div>}</section>
      </>}

      {activeView==='seis' && <section className="six-card"><div className="section-title">Seguimiento de los últimos 6 meses</div><div className="legend"><span><i className="legend-dot gold"/>Ahorro</span><span><i className="legend-dot line"/>Meta mensual: {fmt(calc.mensual)}</span></div><div className="chart">{calc.months.map(m=><div className="bar-col" key={m.key}><div className="bar-value">{m.ahorro?fmt(m.ahorro).replace('COP',''):''}</div><div className="bar-track"><div className="bar-fill" style={{height:`${Math.min(100,m.ahorro/maxChart*100)}%`}}/></div><span>{m.label}</span></div>)}</div><div className="six-summary"><div><span>Objetivo</span><b>{fmt(calc.objetivo)}</b></div><div><span>Necesario por mes</span><b>{fmt(calc.mensual)}</b></div><div><span>Ahorrado este mes</span><b>{fmt(calc.ahorradoEsteMes)}</b></div></div></section>}
      {activeView==='movimientos' && <section><div className="section-title">Todos los movimientos</div>{historial.length===0?<div className="empty-state">Aún no hay movimientos.</div>:<div className="hist-list">{historial.map(t=><TransactionRow key={t.id} t={t} onDelete={deleteTransaccion}/>)}</div>}</section>}
      <div style={{height:105}} />
    </div>
    <div className="fab-row"><button className="fab fab-out" onClick={()=>setFormTipo('gasto')}><Minus size={18}/> Gasto</button><button className="fab fab-save" onClick={()=>setFormTipo('ahorro')}><PiggyBank size={18}/> Ahorro</button><button className="fab fab-in" onClick={()=>setFormTipo('ingreso')}><Plus size={18}/> Ingreso</button></div>
    {formTipo && <TransactionForm tipo={formTipo} onCancel={()=>setFormTipo(null)} onSave={addTransaccion}/>}{showCalc && <CalculatorModal onCancel={()=>setShowCalc(false)}/>} {showSettings && <GoalForm data={data} onCancel={()=>setShowSettings(false)} onSave={saveGoal}/>} {showWelcome && !showSettings && <GoalForm data={data} onCancel={()=>setShowWelcome(false)} onSave={saveGoal} firstTime />}
  </div>;
}

function TransactionRow({t,onDelete}) { return <div className="hist-row"><div className={`hist-dot ${t.tipo==='gasto'?'dot-out':'dot-in'}`}/><div className="hist-body"><div className="hist-top"><span className="hist-nota">{t.nota || (t.tipo==='gasto'?'Gasto':t.tipo==='ahorro'?'Ahorro':'Ingreso')}</span><span className={t.tipo==='gasto'?'hist-amt-out':'hist-amt-in'}>{t.tipo==='gasto'?'-':'+'}{fmt(t.monto)}</span></div><div className="hist-sub">{t.fecha}{t.metaId?' · Meta de ahorro':''}</div></div><button className="del-btn" onClick={()=>onDelete(t.id)}><Trash2 size={14}/></button></div>; }

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;800&family=Inter:wght@400;500;600;700&display=swap');
*{box-sizing:border-box}html,body,#root{margin:0;min-height:100%;background:#0a0908}.app-shell{width:100%;min-height:100vh;background:radial-gradient(circle at 50% -10%,#292016 0,#100e0b 34%,#080807 80%);color:#f4eee3;font-family:Inter,sans-serif;display:flex;justify-content:center;position:relative;overflow-x:hidden}.texture{position:fixed;inset:0;pointer-events:none;opacity:.22;background-image:radial-gradient(#c9a75a 0.55px,transparent .55px);background-size:18px 18px;mask-image:linear-gradient(to bottom,black,transparent 70%)}.app-frame{width:100%;max-width:470px;padding:20px 17px 0;position:relative;z-index:1}.centered{align-items:center}.loader{color:#a99b82}.brand{display:flex;align-items:center;gap:11px;padding:4px 0}.bat{font-size:28px;color:#d7af58;transform:rotate(180deg);filter:drop-shadow(0 0 10px #8d6d2d66)}.brand-name{font-family:Cinzel,serif;font-weight:800;font-size:21px;letter-spacing:.14em;color:#ead4a0}.brand-sub{font-size:9px;letter-spacing:.25em;color:#9c8c70;margin-top:1px}.brand-actions{margin-left:auto;display:flex;gap:7px}.motto{font-family:Cinzel,serif;color:#8f816c;font-size:11px;letter-spacing:.08em;margin:5px 0 17px 39px}.icon-btn{background:#17130e;border:1px solid #3c3020;color:#cbb889;border-radius:11px;padding:8px;display:flex;cursor:pointer}.tabs{display:flex;border-bottom:1px solid #30271b;margin-bottom:14px}.tab{flex:1;border:0;background:none;color:#766b5a;padding:10px 4px;font-weight:700;font-size:12px;cursor:pointer}.tab.active{color:#d7af58;border-bottom:2px solid #d7af58}.available-card,.university-card,.daily-card,.budget-card,.alert-card,.gap-card,.meta-card,.six-card{background:linear-gradient(145deg,#19150f,#0f0e0c);border:1px solid #33291c;box-shadow:0 12px 35px #00000042}.available-card{border-radius:20px;padding:19px}.eyebrow,.card-kicker{font-size:10px;letter-spacing:.16em;color:#94856c;font-weight:700}.available-amount{font-family:Cinzel,serif;font-weight:800;font-size:38px;line-height:1.08;color:#f3e6ca;margin:7px 0 10px}.available-stats{display:flex;gap:17px;color:#9d917d;font-size:12px}.available-stats span{display:flex;gap:5px;align-items:center}.available-stats span:first-child{color:#b8a267}.alert-card{margin-top:11px;border-radius:15px;padding:12px 14px;display:flex;gap:10px;align-items:flex-start}.alert-card strong{font-family:Cinzel,serif;font-size:12px;letter-spacing:.03em}.alert-card p{font-size:11px;color:#928777;margin:4px 0 0;line-height:1.4}.alert-icon{color:#d7af58}.alert-card.rojo{border-color:#654132}.alert-card.rojo .alert-icon{color:#c7775f}.alert-card.amarillo .alert-icon{color:#d7af58}.university-card{margin-top:11px;border-radius:19px;padding:16px;display:flex;align-items:center;gap:16px}.ring-wrap{width:132px;height:132px;position:relative;flex-shrink:0}.ring-center{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center}.ring-center b{font-family:Cinzel,serif;font-size:25px;color:#e4c879}.ring-center span{font-size:9px;color:#817667;letter-spacing:.1em;text-transform:uppercase}.university-info{flex:1}.university-info h2{font-family:Cinzel,serif;font-size:22px;margin:5px 0 10px;color:#eee0c1}.mini-row{display:flex;justify-content:space-between;font-size:11px;margin-top:5px;color:#827767}.mini-row b{color:#d7c39c}.daily-card{margin-top:11px;border-radius:18px;padding:15px;display:flex;gap:12px;align-items:center;border-color:#5b4524}.daily-icon{width:39px;height:39px;border-radius:12px;background:#2b2113;color:#d7af58;display:grid;place-items:center;flex-shrink:0}.daily-number{font-family:Cinzel,serif;font-size:24px;font-weight:800;color:#e5cc8d;margin-top:4px}.daily-number small{font-family:Inter,sans-serif;font-size:10px;color:#8d806c;font-weight:500}.daily-card p{font-size:10.5px;color:#847867;margin:3px 0 0;line-height:1.35}.budget-card{margin-top:11px;border-radius:18px;padding:17px;border-color:#493a22}.budget-head{display:flex;align-items:center;gap:8px;color:#bfa768;font-size:10px;letter-spacing:.12em;font-weight:700}.budget-amount{font-family:Cinzel,serif;font-size:31px;font-weight:800;color:#eee1c3;margin:6px 0}.budget-sub,.gap-sub{font-size:11px;color:#827667;line-height:1.45}.gap-card{margin-top:11px;border-radius:17px;padding:14px;border-color:#5a3c27}.gap-title{font-family:Cinzel,serif;font-size:13px;color:#d7af58;margin-bottom:4px}.section-title{font-family:Cinzel,serif;font-weight:700;font-size:15px;letter-spacing:.04em;margin:22px 0 10px;color:#d9c49a}.metas-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}.meta-card{border-radius:15px;padding:13px}.meta-icon{width:31px;height:31px;border-radius:9px;border:1px solid;display:grid;place-items:center;margin-bottom:9px}.meta-nombre{font-size:11px;color:#a99a84;margin-bottom:3px}.meta-monto{font-family:Cinzel,serif;font-weight:700;font-size:15px}.meta-objetivo{font-size:9.5px;color:#716758;margin:3px 0 8px}.meta-bar-track{height:5px;background:#292117;border-radius:5px;overflow:hidden}.meta-bar-fill{height:100%;border-radius:5px;transition:width .5s}.hist-list{display:flex;flex-direction:column}.hist-row{display:flex;align-items:center;gap:9px;padding:11px 3px;border-bottom:1px solid #211b13}.hist-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}.dot-in{background:#b99a4e;box-shadow:0 0 8px #b99a4e55}.dot-out{background:#a95f49}.hist-body{flex:1;min-width:0}.hist-top{display:flex;justify-content:space-between;gap:8px}.hist-nota{font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.hist-amt-in,.hist-amt-out{font-size:12px;font-weight:700;flex-shrink:0}.hist-amt-in{color:#cdb36f}.hist-amt-out{color:#bc755e}.hist-sub{font-size:9.5px;color:#6f6558;margin-top:3px}.del-btn{background:none;border:0;color:#4d453b;cursor:pointer;padding:5px}.empty-state{font-size:12px;color:#766d60;background:#13110e;border:1px dashed #33291e;border-radius:14px;padding:20px;text-align:center}.fab-row{position:fixed;bottom:13px;left:50%;transform:translateX(-50%);width:100%;max-width:470px;padding:0 13px;display:flex;gap:7px;z-index:30}.fab{flex:1;border-radius:14px;padding:13px 7px;border:1px solid #3b3022;font-weight:800;font-size:11px;display:flex;align-items:center;justify-content:center;gap:5px;cursor:pointer;box-shadow:0 9px 28px #00000070}.fab-out{background:#17130f;color:#c9b99b}.fab-save{background:#2a2115;color:#d7af58;border-color:#5b4625}.fab-in{background:#d7af58;color:#17120c;border-color:#d7af58}.modal-backdrop{position:fixed;inset:0;background:#050403cc;display:flex;align-items:flex-end;justify-content:center;z-index:50;backdrop-filter:blur(4px)}.modal{width:100%;max-width:470px;max-height:90vh;overflow:auto;background:linear-gradient(145deg,#1b1711,#0e0d0b);border:1px solid #443522;border-radius:22px 22px 0 0;padding:20px 17px 28px;box-shadow:0 -15px 50px #000}.setup-text{font-size:12px;color:#8f816c;line-height:1.5;margin:-4px 0 15px}.goal-link{margin-top:8px;background:none;border:0;color:#d7af58;font-weight:800;font-size:11px;padding:0;cursor:pointer;text-decoration:underline}.modal-head{display:flex;justify-content:space-between;align-items:center;font-family:Cinzel,serif;font-weight:700;font-size:14px;margin-bottom:16px;color:#e1cea0}.field-label{font-size:10px;letter-spacing:.1em;color:#887b69;margin-bottom:6px;display:block;text-transform:uppercase}.field-input{width:100%;background:#0b0a08;border:1px solid #3a2e20;color:#eee3cd;border-radius:11px;padding:12px 13px;font-size:15px;margin-bottom:13px;outline:none}.field-input:focus{border-color:#8d6e36}.chip-row{display:flex;flex-wrap:wrap;gap:7px;margin-bottom:13px}.chip{background:#0c0b09;border:1px solid #33291e;color:#9c907e;border-radius:20px;padding:7px 10px;font-size:10.5px;cursor:pointer}.chip-active{background:#251d12;color:#d7af58}.submit-btn{width:100%;border:0;border-radius:12px;padding:13px;font-weight:800;font-size:13px;cursor:pointer}.submit-in{background:#d7af58;color:#17120c}.submit-out{background:#6d3e31;color:#f3dfd4}.calc-ops{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin:-3px 0 12px}.calc-op{background:#16120e;border:1px solid #33291e;color:#b7a78c;border-radius:10px;padding:10px;font-size:17px}.calc-op.active{color:#d7af58;border-color:#80632f;background:#241c11}.calc-result{font-family:Cinzel,serif;font-size:30px;color:#e4c97e;text-align:center;border-top:1px solid #2e251a;padding-top:15px}.six-card{border-radius:19px;padding:15px}.legend{display:flex;flex-direction:column;gap:5px;color:#7e7467;font-size:9.5px}.legend span{display:flex;align-items:center;gap:6px}.legend-dot{width:7px;height:7px;border-radius:50%;display:inline-block}.gold{background:#d7af58}.line{border:1px solid #69593e}.chart{height:230px;display:flex;align-items:end;gap:8px;padding:20px 3px 4px;border-bottom:1px solid #30271c;margin-top:8px}.bar-col{height:100%;flex:1;display:flex;flex-direction:column;align-items:center;justify-content:end;gap:5px}.bar-value{font-size:7px;color:#8d7e67;height:18px;white-space:nowrap;overflow:hidden;max-width:100%;text-overflow:ellipsis}.bar-track{height:165px;width:22px;background:#211a12;border-radius:8px;display:flex;align-items:end;overflow:hidden}.bar-fill{width:100%;background:linear-gradient(to top,#765a2d,#d7af58);border-radius:8px 8px 0 0;min-height:2px}.bar-col>span{font-size:9px;color:#776d5e;text-transform:uppercase}.six-summary{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:15px}.six-summary div{background:#13100d;border:1px solid #2d2419;border-radius:12px;padding:10px}.six-summary span{display:block;color:#766b5c;font-size:9px}.six-summary b{display:block;color:#d8c397;font-family:Cinzel,serif;font-size:13px;margin-top:4px}@media(min-width:700px){.app-frame{padding-top:30px}.fab-row{bottom:20px}}
`;

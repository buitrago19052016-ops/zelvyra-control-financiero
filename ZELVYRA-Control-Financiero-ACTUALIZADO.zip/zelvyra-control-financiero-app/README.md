# ZELVYRA — Control Financiero

Aplicación móvil de finanzas personales con estética gótica elegante: negro, carbón y dorado.

## Incluye
- Dinero disponible en tiempo real según movimientos registrados.
- Registro de ingresos, gastos y ahorros.
- Meta principal de universidad de $5.000.000 en 6 meses.
- Otras metas: restaurante, emergencia y moto/tecnología/SOAT/impuestos.
- Barras y anillo de progreso.
- Indicador de ahorro diario necesario para llegar a la meta.
- Presupuesto diario y alerta cuando el gasto compromete el objetivo.
- Seguimiento de 6 meses.
- Historial de movimientos con eliminación.
- Calculadora integrada.
- Configuración de ingreso y gasto mensual estimados.
- Persistencia local: localStorage, para conservar datos al cerrar la app.
- Manifest PWA, icono y pantalla de inicio.
- Capacitor preparado para Android e iOS.

## Nombre e identidad
**ZELVYRA**  
**CONTROL FINANCIERO**  
“Cada peso tiene un propósito.”

## Abrir como aplicación web
Instalar dependencias y ejecutar:

```bash
npm install
npm run dev
```

## Generar la versión web de producción

```bash
npm install
npm run build
```

## Android / GitHub Actions
El proyecto incluye un workflow de GitHub Actions en `.github/workflows/android.yml`.
Al hacer push a `main` o `master`, el workflow instala Node.js 24 y Java 17,
crea la plataforma Android de Capacitor y genera automáticamente un APK de prueba.

El APK queda disponible como artefacto `zelvyra-debug-apk` en la ejecución del workflow.

Para trabajar localmente con Android Studio:


```bash
npm install
npm run cap:add:android
npm run cap:sync
npm run cap:open:android
```

Desde Android Studio se puede generar un APK de prueba o un AAB firmado para Google Play.

## iOS
En macOS con Xcode instalado:

```bash
npm install
npm run cap:add:ios
npm run cap:sync
npm run cap:open:ios
```

Desde Xcode se configura la firma, el equipo de Apple y el envío a App Store Connect.

## Importante
Este ZIP es el proyecto fuente multiplataforma. Los binarios firmados de Google Play y App Store requieren sus respectivos SDK/IDE y certificados de publicación.
